/*
 * File:   interrupts.c
 * Author: RomiC
 *
 * Created on 27 aprile 2024, 23.19
 */


#include "xc.h"

